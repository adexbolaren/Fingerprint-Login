/*Clase que controla el funcionamiento del reloj en frame del lector*/
package Internals;

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class clock extends Thread{
    private final JLabel lbl;
    
    public clock(JLabel lbl){
        //Actualizar el valor de la etiqueta con la hora...
        this.lbl = lbl;
    }
    
    //Metodo que carga el hilo..
    @Override
    public void run(){
        while(true){
            Date now = new Date();
            SimpleDateFormat formato = new SimpleDateFormat("dd-MMM-yy   hh:mm:ss a");
            lbl.setText(formato.format(now));
            lbl.setForeground(new java.awt.Color(0, 153, 102));
            lbl.setFont(new java.awt.Font("Castellar", 0, 16));
            
            try{
                sleep(1000);
            }catch(Exception ex){
                JOptionPane.showMessageDialog(null,"Oops! Something went wrong with the time" + ex);
            }
        }
    }
    
}
